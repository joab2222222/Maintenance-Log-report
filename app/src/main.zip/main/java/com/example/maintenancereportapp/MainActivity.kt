powershell.exe -NoProfile -Command "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard" > app/src/main/java/com/example/maintenancereportapp/MainActivity.kt
